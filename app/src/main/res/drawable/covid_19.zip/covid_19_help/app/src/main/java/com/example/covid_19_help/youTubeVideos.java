package com.example.covid_19_help;

public class youTubeVideos {
    String videoUrl;
    public youTubeVideos() {
    }
    public youTubeVideos(String videoUrl) {
        this.videoUrl = videoUrl;
    }
    public String getVideoUrl() {
        return videoUrl;
    }
    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
